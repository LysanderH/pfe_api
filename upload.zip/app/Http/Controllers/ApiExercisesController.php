<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ApiExercisesController extends Controller
{
    public function show(Request $request)
    {
        # code...
    }
}
